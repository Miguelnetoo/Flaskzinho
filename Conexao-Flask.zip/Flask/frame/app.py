from flask import Flask, render_template, request

app = Flask(__name__)

from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('contamination_form.html')

@app.route('/detect_contamination', methods=['POST'])
def detect_contamination():
    temperature = request.form['temperature']
    has_mold = request.form['has_mold']
    expired_food = request.form['expired_food']

    if temperature == 'high':
        result = 'Temperatura alta. Risco de contaminação!'
    elif has_mold == 'yes':
        result = 'Presença de mofo detectada. Ação necessária!'
    elif expired_food == 'yes':
        result = 'Alimentos fora da validade. Risco de contaminação!'
    else:
        result = 'A geladeira está limpa. Nenhuma contaminação detectada.'

    return render_template('contamination_result.html', result=result)

if __name__ == '__main__':
    app.run()